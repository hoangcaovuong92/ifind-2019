<?php

namespace OTGS\Toolset\Types\Field\Group\Term;

/**
 * Handles the Deletion of a Term Field Group.
 *
 * Until now nothing else required than for Users.
 *
 * @package OTGS\Toolset\Types\Field\Group\Term
 *
 * @since 3.2
 */
class Deletion extends \OTGS\Toolset\Types\Field\Group\User\Deletion {}