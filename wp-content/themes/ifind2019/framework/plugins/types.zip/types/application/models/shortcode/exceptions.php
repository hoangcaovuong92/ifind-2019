<?php

/**
 * Class Exception_Invalid_Shortcode_Attr_Item
 *
 * @since 2.3
 */
class Exception_Invalid_Shortcode_Attr_Item extends Exception {}


/**
 * Class Exception_Invalid_Shortcode_Attr_Field
 *
 * @since 2.3
 */
class Exception_Invalid_Shortcode_Attr_Field extends Exception {}